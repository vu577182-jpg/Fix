package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * AutoXP — tự động ném Experience Bottle (EXP bottle / bottle o' enchanting)
 * khi XP level dưới ngưỡng, và pickup XP orb trong range.
 *
 * Mode:
 *   ThrowBottle — ném exp bottle từ inventory/offhand định kỳ
 *   PickupOrb   — teleport-pick (move nhẹ về phía orb gần nhất để trigger pickup)
 */
public final class AutoXP extends Module {

    private final BooleanSetting throwBottle = add(new BooleanSetting(
            "ThrowBottle",
            "Tự động ném exp bottle khi có trong inventory.",
            true
    ));

    private final NumberSetting targetLevel = add(new NumberSetting(
            "TargetLevel",
            "Dừng ném khi XP level đạt ngưỡng này.",
            30, 0, 100
    ));

    private final NumberSetting throwDelay = add(new NumberSetting(
            "ThrowDelay",
            "Delay ticks giữa các lần ném (1-40).",
            5, 1, 40
    ));

    private final BooleanSetting pickupOrb = add(new BooleanSetting(
            "PickupOrb",
            "Tự động nhặt XP orb trong range.",
            false
    ));

    private final NumberSetting pickupRange = add(new NumberSetting(
            "PickupRange",
            "Range nhặt XP orb (blocks).",
            4f, 1f, 10f
    ));

    private int cooldown = 0;

    public AutoXP() {
        super("AutoXP", "Tự động ném exp bottle và nhặt XP orb.", Category.MISC);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!isEnabled()) return;
            if (client.player == null || client.level == null) return;
            tick(client.player);
        });
    }

    private void tick(LocalPlayer player) {
        if (cooldown > 0) { cooldown--; return; }

        // --- throw bottle ----------------------------------------------------
        if (throwBottle.get() && player.experienceLevel < (int) targetLevel.getFloat()) {
            int bottleSlot = findExpBottle(player);
            if (bottleSlot >= 0) {
                int prev = player.getInventory().selected;
                player.getInventory().selected = bottleSlot;
                mc.gameMode.useItem(player, net.minecraft.world.InteractionHand.MAIN_HAND);
                player.getInventory().selected = prev;
                cooldown = (int) throwDelay.getFloat();
                return;
            }
        }

        // --- pickup orb ------------------------------------------------------
        if (pickupOrb.get()) {
            float range = pickupRange.getFloat();
            AABB box = player.getBoundingBox().inflate(range);
            List<ExperienceOrb> orbs = player.level().getEntitiesOfClass(
                    ExperienceOrb.class, box);
            if (!orbs.isEmpty()) {
                ExperienceOrb nearest = orbs.get(0);
                double minDist = player.distanceToSqr(nearest);
                for (ExperienceOrb o : orbs) {
                    double d = player.distanceToSqr(o);
                    if (d < minDist) { minDist = d; nearest = o; }
                }
                // nudge player position về phía orb để trigger pickup
                double dx = nearest.getX() - player.getX();
                double dz = nearest.getZ() - player.getZ();
                double len = Math.sqrt(dx*dx + dz*dz);
                if (len > 0.01) {
                    player.setDeltaMovement(
                            player.getDeltaMovement().add(dx/len * 0.05, 0, dz/len * 0.05));
                }
                cooldown = 1;
            }
        }
    }

    /**
     * Tìm Experience Bottle trong hotbar (0-8) trước, rồi inventory.
     * @return hotbar slot index (0-8), -1 nếu không tìm thấy.
     */
    private int findExpBottle(LocalPlayer player) {
        var inv = player.getInventory();
        // hotbar
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).getItem() == Items.EXPERIENCE_BOTTLE) return i;
        }
        // main inventory — cần swap về hotbar trước khi throw
        // đây chỉ trả về -1 nếu không có trên hotbar (có thể mở rộng sau)
        return -1;
    }
}
