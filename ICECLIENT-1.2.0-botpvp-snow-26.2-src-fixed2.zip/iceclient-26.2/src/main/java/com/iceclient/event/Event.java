package com.iceclient.event;

/** Base class for every event dispatched on the {@link EventBus}. */
public class Event {
    private boolean cancelled;

    public void cancel() { cancelled = true; }
    public boolean isCancelled() { return cancelled; }
}
