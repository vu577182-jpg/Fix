package com.iceclient.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    HUD("HUD"),
    MISC("Misc"),
    CLIENT("Client");

    public final String label;

    Category(String label) { this.label = label; }
}
