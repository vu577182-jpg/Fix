package com.iceclient.module.combat;

import com.iceclient.manager.NotificationManager;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.BlockUtil;
import com.iceclient.util.InventoryUtil;
import com.iceclient.util.TargetUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Places a respawn anchor near the target, charges it with glowstone and detonates it (Overworld / End only). */
public final class AutoAnchor extends Module {
    private final NumberSetting targetRange = add(new NumberSetting("TargetRange", "Max distance to pick a target", 8, 3, 12, 0.5));
    private final NumberSetting placeRange = add(new NumberSetting("PlaceRange", "Max reach", 4.5, 1, 6, 0.1));
    private final NumberSetting minSelf = add(new NumberSetting("MinSelfDist", "Anchor must be at least this far from you", 3.5, 2, 8, 0.5));
    private final NumberSetting minHealth = add(new NumberSetting("MinHealth", "Stop when your health is below this", 10, 1, 20, 1));
    private final NumberSetting delay = add(new NumberSetting("Delay", "Ticks between actions", 2, 0, 10, 1));
    private final BooleanSetting rotate = add(new BooleanSetting("Rotate", "Send rotation packets", true));

    private int timer;

    public AutoAnchor() {
        super("AutoAnchor", "Dat, nap glowstone va no respawn anchor vao muc tieu.", Category.COMBAT);
    }

    @Override
    protected String checkCanEnable() {
        if (mc.level.dimension() == Level.NETHER) return "Anchor chi no o Overworld/End";
        return null;
    }

    @Override
    protected void onEnable() { timer = 0; }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (mc.level.dimension() == Level.NETHER) {
            NotificationManager.warn(name, "Dang o Nether - da tat");
            setEnabled(false);
            return;
        }
        if (timer > 0) { timer--; return; }
        if (p.getHealth() < minHealth.f()) return;
        Player target = TargetUtil.nearestPlayer(targetRange.d());
        if (target == null) return;

        BlockPos pos = choosePos(p, target);
        if (pos == null) return;

        int previous = InventoryUtil.selected();
        try {
            BlockState state = mc.level.getBlockState(pos);
            if (state.isAir()) {
                int slot = InventoryUtil.findHotbar(Items.RESPAWN_ANCHOR);
                if (slot == -1) return;
                InventoryUtil.select(slot);
                if (BlockUtil.place(pos, InteractionHand.MAIN_HAND, rotate.on())) timer = delay.i();
            } else if (state.getBlock() == Blocks.RESPAWN_ANCHOR) {
                int charge = state.getValue(RespawnAnchorBlock.CHARGE);
                if (charge < 1) {
                    int slot = InventoryUtil.findHotbar(Items.GLOWSTONE);
                    if (slot == -1) return;
                    InventoryUtil.select(slot);
                    if (BlockUtil.use(pos, Direction.UP, InteractionHand.MAIN_HAND, rotate.on())) timer = delay.i();
                } else {
                    if (InventoryUtil.isItem(p.getOffhandItem(), Items.GLOWSTONE)) return; // would recharge instead of exploding
                    int slot = InventoryUtil.findHotbar(s -> !InventoryUtil.isItem(s, Items.GLOWSTONE));
                    if (slot == -1) return;
                    InventoryUtil.select(slot);
                    if (BlockUtil.use(pos, Direction.UP, InteractionHand.MAIN_HAND, rotate.on())) timer = delay.i();
                }
            }
        } finally {
            InventoryUtil.select(previous);
        }
    }

    private BlockPos choosePos(LocalPlayer p, Player target) {
        BlockPos feet = target.blockPosition();
        List<BlockPos> candidates = new ArrayList<>();
        candidates.add(feet.above(2));
        for (Direction d : Direction.Plane.HORIZONTAL) {
            candidates.add(feet.relative(d).above(1));
            candidates.add(feet.relative(d));
        }
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        double reachSq = placeRange.d() * placeRange.d();
        double minSq = minSelf.d() * minSelf.d();
        for (BlockPos c : candidates) {
            BlockState state = mc.level.getBlockState(c);
            boolean anchor = state.getBlock() == Blocks.RESPAWN_ANCHOR;
            if (!anchor && !state.isAir()) continue;
            if (!anchor && (!BlockUtil.hasSupport(c) || BlockUtil.entityIn(c))) continue;
            Vec3 center = Vec3.atCenterOf(c);
            if (p.getEyePosition().distanceToSqr(center) > reachSq) continue;
            if (p.position().distanceToSqr(center) < minSq) continue;
            double score = center.distanceToSqr(target.position()) - (anchor ? 100 : 0);
            if (score < bestScore) { bestScore = score; best = c; }
        }
        return best;
    }
}
