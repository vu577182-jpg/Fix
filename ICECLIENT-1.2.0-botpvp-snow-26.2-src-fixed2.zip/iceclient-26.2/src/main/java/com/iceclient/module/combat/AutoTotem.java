package com.iceclient.module.combat;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * AutoTotem — tự động giữ totem ở offhand.
 * AutoMainhand — đặt totem vào hotbar slot 1-9 khi cần.
 *
 * Swap dùng handleInventoryMouseClick:
 *   SWAP button 40  = swap inventory slot với offhand (1.17+, 1-click)
 *   PICKUP 3-click  = tương thích cũ hơn
 *
 * Tick logic đăng ký qua Fabric ClientTickEvents.END_CLIENT_TICK trong constructor.
 * Check isEnabled() bên trong callback để tôn trọng toggle.
 */
public final class AutoTotem extends Module {

    // ---- settings -----------------------------------------------------------

    private final NumberSetting health = add(new NumberSetting(
            "Health",
            "Ngưỡng HP + absorb để ưu tiên totem vào offhand.",
            18, 1, 36
    ));

    private final BooleanSetting swapMode = add(new BooleanSetting(
            "SwapMode",
            "Dùng SWAP 1-click (1.17+). Tắt → 3x PICKUP.",
            true
    ));

    private final BooleanSetting autoMainhand = add(new BooleanSetting(
            "AutoMainhand",
            "Đặt totem vào hotbar slot khi offhand đã có totem hoặc không còn totem.",
            false
    ));

    private final NumberSetting mainhandSlot = add(new NumberSetting(
            "MainhandSlot",
            "Hotbar slot nhận totem khi AutoMainhand bật (1-9 → index 0-8).",
            1, 1, 9
    ));

    // ---- container slot constants ------------------------------------------

    /** Offhand slot trong InventoryMenu. */
    private static final int OFFHAND_SLOT = 45;

    /** Hotbar container slot bắt đầu (hotbar raw 0 = container 36). */
    private static final int HOTBAR_BASE = 36;

    // ---- state --------------------------------------------------------------

    private int cooldown = 0;

    // -------------------------------------------------------------------------

    public AutoTotem() {
        super("AutoTotem", "Tự động giữ totem ở offhand và mainhand.", Category.COMBAT);

        // Đăng ký tick callback qua Fabric — không cần Module base có onTick()
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!isEnabled()) return;
            if (client.player == null || client.level == null) return;
            tick(client.player);
        });
    }

    // ---- core tick ----------------------------------------------------------

    private void tick(LocalPlayer player) {
        if (cooldown > 0) { cooldown--; return; }

        ItemStack offhand         = player.getOffhandItem();
        boolean   offhandHasTotem = offhand.getItem() == Items.TOTEM_OF_UNDYING;
        float     hp              = player.getHealth() + player.getAbsorptionAmount();

        // --- offhand logic ---------------------------------------------------
        if (!offhandHasTotem && hp <= health.getFloat()) {
            if (swapTotemToOffhand(player)) {
                cooldown = 2;
                return;
            }
        }

        // --- mainhand logic --------------------------------------------------
        if (autoMainhand.get()) {
            handleMainhand(player, offhandHasTotem);
        }
    }

    // ---- swap totem → offhand -----------------------------------------------

    private boolean swapTotemToOffhand(LocalPlayer player) {
        int raw = findTotem(player);
        if (raw < 0) return false;

        // mở inventory nếu đang đóng để click có effect
        
        int     src    = rawToContainer(raw);
        int     menuId = player.inventoryMenu.containerId;

        if (swapMode.get()) {
            // 1-click: SWAP với offhand (button 40 = F-key / offhand)
            mc.gameMode.handleContainerInput(menuId, src, 40, ContainerInput.SWAP, player);
        } else {
            // 3-click PICKUP
            mc.gameMode.handleContainerInput(menuId, src, 0, ContainerInput.PICKUP, player);
            mc.gameMode.handleContainerInput(menuId, OFFHAND_SLOT, 0, ContainerInput.PICKUP, player);

            // nếu offhand không rỗng thì cursor đang giữ item cũ — cần đặt xuống đâu đó
            if (!player.getOffhandItem().isEmpty()) {
                int empty = findEmpty(player);
                int dest  = empty >= 0 ? rawToContainer(empty) : -999; // -999 = drop
                mc.gameMode.handleContainerInput(menuId, dest, 0, ContainerInput.PICKUP, player);
            }
        }
        return true;
    }

    // ---- mainhand logic -----------------------------------------------------

    /**
     * Hotbar slot target = mainhandSlot.getInt() - 1 (setting 1-9 → index 0-8).
     *
     * Nếu offhand đã có totem và mainhand target trống → đặt totem vào mainhand.
     * Nếu cả 2 đều có totem → giữ nguyên (đủ rồi).
     * Nếu không có totem nào → không làm gì (offhand logic lo).
     */
    private void handleMainhand(LocalPlayer player, boolean offhandHasTotem) {
        int     hotbarIdx     = mainhandSlot.getInt() - 1; // 1-9 → 0-8
        int     hotbarCont    = HOTBAR_BASE + hotbarIdx;
        int     menuId        = player.inventoryMenu.containerId;
        boolean mainHasTotem  = player.getInventory().getItem(hotbarIdx)
                                      .getItem() == Items.TOTEM_OF_UNDYING;

        if (mainHasTotem) return; // mainhand đã có totem rồi

        if (!offhandHasTotem) return; // offhand chưa có — để offhand logic xử lý trước

        // offhand có totem, mainhand chưa có → tìm totem thứ 2 trong inv
        int raw = findTotem(player, hotbarIdx);
        if (raw < 0) return;

        int src = rawToContainer(raw);

        // nếu mainhand đang có item khác → swap 2 chiều
        boolean mainEmpty = player.getInventory().getItem(hotbarIdx).isEmpty();

        mc.gameMode.handleContainerInput(menuId, src, 0, ContainerInput.PICKUP, player);
        mc.gameMode.handleContainerInput(menuId, hotbarCont, 0, ContainerInput.PICKUP, player);
        if (!mainEmpty) {
            // item cũ từ hotbar ra cursor — đặt về slot gốc của totem
            mc.gameMode.handleContainerInput(menuId, src, 0, ContainerInput.PICKUP, player);
        }
        cooldown = 2;
    }

    // ---- helpers ------------------------------------------------------------

    /**
     * Tìm totem đầu tiên trong inventory.
     * Ưu tiên main inv (9–35) trước hotbar (0–8) để tránh đụng selected slot.
     * @return raw inventory index (0–35), -1 nếu không có.
     */
    private int findTotem(LocalPlayer player) {
        return findTotem(player, -1);
    }

    /**
     * Tìm totem, bỏ qua raw slot `skip`.
     */
    private int findTotem(LocalPlayer player, int skip) {
        Inventory inv = player.getInventory();
        for (int i = 9; i < 36; i++) {
            if (i != skip && inv.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (i != skip && inv.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        return -1;
    }

    /** Slot trống đầu tiên (raw 0–35), -1 nếu full. */
    private int findEmpty(LocalPlayer player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).isEmpty()) return i;
        }
        return -1;
    }

    /**
     * Raw inventory index → InventoryMenu container slot.
     *
     * InventoryMenu layout:
     *   0        crafting result
     *   1–4      crafting grid
     *   5–8      armor
     *   9–35     main inventory  (raw 9–35, 1:1)
     *   36–44    hotbar          (raw 0–8  → +36)
     *   45       offhand
     */
    private static int rawToContainer(int raw) {
        return raw < 9 ? HOTBAR_BASE + raw : raw;
    }

    /** Lấy int value từ NumberSetting — wrapper tiện lợi. */
    private int mainhandSlotInt() {
        return (int) mainhandSlot.getFloat();
    }
}
