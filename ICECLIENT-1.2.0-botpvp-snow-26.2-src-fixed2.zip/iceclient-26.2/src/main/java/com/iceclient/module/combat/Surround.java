package com.iceclient.module.combat;

import com.iceclient.manager.NotificationManager;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.BlockUtil;
import com.iceclient.util.InventoryUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/** Surrounds the player's feet with obsidian. */
public final class Surround extends Module {
    private final NumberSetting perTick = add(new NumberSetting("Blocks/Tick", "Blocks placed per tick", 4, 1, 8, 1));
    private final NumberSetting delay = add(new NumberSetting("Delay", "Ticks between placement rounds", 0, 0, 5, 1));
    private final BooleanSetting support = add(new BooleanSetting("Support", "Place a block underneath first if the floor is missing", true));
    private final BooleanSetting rotate = add(new BooleanSetting("Rotate", "Send rotation packets when placing", false));
    private final BooleanSetting disableOnJump = add(new BooleanSetting("DisableOnJump", "Turn off when you change height", true));

    private int startY;
    private int timer;

    public Surround() {
        super("Surround", "Dat obsidian bao quanh chan nguoi choi.", Category.COMBAT);
    }

    @Override
    protected String checkCanEnable() {
        return InventoryUtil.findHotbar(Items.OBSIDIAN) == -1 ? "Can obsidian tren hotbar" : null;
    }

    @Override
    protected void onEnable() {
        startY = mc.player.blockPosition().getY();
        timer = 0;
    }

    @Override
    public void onTick() {
        if (disableOnJump.on() && mc.player.blockPosition().getY() != startY) {
            NotificationManager.info(name, "Tat do doi do cao");
            setEnabled(false);
            return;
        }
        if (timer-- > 0) return;
        timer = delay.i();

        int slot = InventoryUtil.findHotbar(Items.OBSIDIAN);
        if (slot == -1) {
            NotificationManager.warn(name, "Het obsidian");
            setEnabled(false);
            return;
        }

        BlockPos feet = mc.player.blockPosition();
        int previous = InventoryUtil.selected();
        int placed = 0;
        InventoryUtil.select(slot);
        try {
            for (Direction d : Direction.Plane.HORIZONTAL) {
                if (placed >= perTick.i()) break;
                BlockPos cell = feet.relative(d);
                if (!BlockUtil.isAir(cell)) continue;
                if (support.on() && BlockUtil.isAir(cell.below()) && placed < perTick.i()) {
                    if (BlockUtil.place(cell.below(), InteractionHand.MAIN_HAND, rotate.on())) placed++;
                }
                if (placed < perTick.i() && BlockUtil.place(cell, InteractionHand.MAIN_HAND, rotate.on())) placed++;
            }
        } finally {
            InventoryUtil.select(previous);
        }
    }
}
