package com.iceclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumberSetting extends Setting<Double> {
    public final double min, max, step;

    /** Constructor without step — defaults to step=1. */
    public NumberSetting(String name, String description, double value, double min, double max) {
        this(name, description, value, min, max, 1);
    }

    public NumberSetting(String name, String description, double value, double min, double max, double step) {
        super(name, description, value);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double d() { return value; }
    public float f() { return value.floatValue(); }
    public int i() { return (int) Math.round(value); }

    /** Alias for f() — convenience for callers using getFloat() style. */
    public float getFloat() { return f(); }
    /** Alias for i() — convenience for callers using getInt() style. */
    public int getInt() { return i(); }

    @Override
    public void set(Double v) {
        double clamped = Math.max(min, Math.min(max, v));
        if (step > 0) clamped = Math.round((clamped - min) / step) * step + min;
        this.value = Math.max(min, Math.min(max, clamped));
    }

    public String display() {
        if (step >= 1 && Math.floor(step) == step) return String.valueOf((int) Math.round(value));
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) set(e.getAsDouble()); }
}
