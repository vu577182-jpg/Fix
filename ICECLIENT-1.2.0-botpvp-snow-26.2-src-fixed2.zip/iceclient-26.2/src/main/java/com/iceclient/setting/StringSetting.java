package com.iceclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class StringSetting extends Setting<String> {
    public StringSetting(String name, String description, String value) { super(name, description, value); }

    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) value = e.getAsString(); }
}
