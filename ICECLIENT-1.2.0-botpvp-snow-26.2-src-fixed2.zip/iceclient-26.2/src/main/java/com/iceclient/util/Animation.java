package com.iceclient.util;

/** Frame-rate independent exponential smoothing. */
public final class Animation {
    private float value, target;
    private long last = System.nanoTime();
    private final float speed;

    public Animation(float initial) { this(initial, 14f); }
    public Animation(float initial, float speed) { this.value = initial; this.target = initial; this.speed = speed; }

    public void set(float target) { this.target = target; }
    public void snap(float v) { this.value = v; this.target = v; }
    public float target() { return target; }

    public float get() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
        value += (target - value) * (1f - (float) Math.exp(-speed * dt));
        if (Math.abs(target - value) < 0.001f) value = target;
        return value;
    }
}
