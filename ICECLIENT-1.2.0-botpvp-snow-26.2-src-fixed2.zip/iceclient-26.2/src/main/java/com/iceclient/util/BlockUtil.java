package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public final class BlockUtil {
    public static final double REACH_SQ = 6.0 * 6.0;

    private BlockUtil() {}

    public static boolean isAir(BlockPos pos) {
        return Minecraft.getInstance().level.getBlockState(pos).isAir();
    }

    /** True when a non-item entity occupies the block cell. */
    public static boolean entityIn(BlockPos pos) {
        for (Entity e : Minecraft.getInstance().level.getEntitiesOfClass(Entity.class, new AABB(pos))) {
            if (!(e instanceof ItemEntity)) return true;
        }
        return false;
    }

    public static boolean hasSupport(BlockPos pos) {
        for (Direction d : Direction.values()) if (!isAir(pos.relative(d))) return true;
        return false;
    }

    /** Right-clicks {@code target} on {@code face} with the given hand. */
    public static boolean use(BlockPos target, Direction face, InteractionHand hand, boolean rotate) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        Vec3 hit = Vec3.atCenterOf(target).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
        if (p.getEyePosition().distanceToSqr(hit) > REACH_SQ) return false;
        if (rotate) RotationUtil.face(hit);
        mc.gameMode.useItemOn(p, hand, new BlockHitResult(hit, face, target, false));
        p.swing(hand);
        return true;
    }

    /** Places the held item into the empty cell {@code pos} against any solid neighbour. */
    public static boolean place(BlockPos pos, InteractionHand hand, boolean rotate) {
        if (!isAir(pos) || entityIn(pos)) return false;
        for (Direction d : Direction.values()) {
            BlockPos neighbour = pos.relative(d);
            if (isAir(neighbour)) continue;
            if (use(neighbour, d.getOpposite(), hand, rotate)) return true;
        }
        return false;
    }
}
