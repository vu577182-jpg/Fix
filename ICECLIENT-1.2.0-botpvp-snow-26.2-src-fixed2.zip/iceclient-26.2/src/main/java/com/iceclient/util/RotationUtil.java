package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class RotationUtil {
    private RotationUtil() {}

    public static float[] to(Vec3 target) {
        LocalPlayer p = Minecraft.getInstance().player;
        Vec3 eye = p.getEyePosition();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = Mth.clamp((float) -Math.toDegrees(Math.atan2(dy, h)), -90f, 90f);
        return new float[]{yaw, pitch};
    }

    /** Sends a rotation-only packet so the server sees us looking at the target (client camera is untouched). */
    public static void face(Vec3 target) {
        send(to(target));
    }

    public static void send(float[] rot) {
        send(rot[0], rot[1]);
    }

    public static void send(float yaw, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.getConnection() == null) return;
        mc.getConnection().send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, p.onGround(), p.horizontalCollision));
    }
}
