package com.iceclient.util;

/** ICE PRO palette (ARGB) — deeper ice / frost theme. */
public final class Theme {
    // Backgrounds
    public static final int BG        = 0xFF060B14;
    public static final int BG_LIGHT  = 0xFF0A1220;
    public static final int CARD      = 0xFF0C1628;
    public static final int CARD_HOVER= 0xFF122038;

    // Accents
    public static final int PRIMARY   = 0xFF5EC8FF;   // bright ice blue
    public static final int SECONDARY = 0xFFB8E8FF;   // soft frost
    public static final int ACCENT    = 0xFF3AA0E8;   // deeper cyan
    public static final int GLOW      = 0xFF9DE8FF;   // highlight

    // UI chrome
    public static final int BORDER    = 0xFF1E3A55;
    public static final int BORDER_LIT= 0xFF3A6A90;
    public static final int TEXT      = 0xFFF0FAFF;
    public static final int MUTED     = 0xFF7A96B0;
    public static final int TRACK_OFF = 0xFF152536;

    // Status
    public static final int WARN      = 0xFFFFC857;
    public static final int DANGER    = 0xFFFF6B7A;
    public static final int OK        = 0xFF6BFFB0;

    private Theme() {}

    public static int alpha(int rgb, int a) {
        return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8)  & 255) + (((b >> 8)  & 255) - ((a >> 8)  & 255)) * t);
        int ab = (int) (( a        & 255) + (( b        & 255) - ( a        & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    /** Soft pulse between two colors based on time. */
    public static int pulse(int a, int b, float speed) {
        float t = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 1000.0 * speed));
        return lerp(a, b, t);
    }
}
