package com.iceclient.module.player;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;

/** Refills hotbar stacks from the main inventory when they run low. */
public final class Replenish extends Module {
    private final NumberSetting threshold = add(new NumberSetting("Threshold", "Refill when the stack is at or below this size", 8, 1, 32, 1));
    private final NumberSetting delay = add(new NumberSetting("Delay", "Ticks between swaps", 3, 0, 20, 1));

    private int timer;

    public Replenish() {
        super("Replenish", "Tu dong bo sung vat pham tren hotbar tu hanh trang.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (timer-- > 0) return;
        LocalPlayer p = mc.player;
        if (mc.gui.screen != null || p.containerMenu.containerId != 0 || mc.gameMode == null) return;

        Inventory inv = p.getInventory();
        for (int hot = 0; hot < 9; hot++) {
            ItemStack stack = inv.getItem(hot);
            if (stack.isEmpty() || !stack.isStackable() || stack.getCount() > threshold.i()) continue;

            int bestSlot = -1, bestCount = 0;
            for (int i = 9; i < 36; i++) {
                ItemStack other = inv.getItem(i);
                if (other.isEmpty() || other.getItem() != stack.getItem()) continue;
                if (!ItemStack.isSameItemSameComponents(stack, other)) continue;
                if (other.getCount() > bestCount) { bestCount = other.getCount(); bestSlot = i; }
            }
            if (bestSlot == -1) continue;

            // Menu slot ids for the player inventory: main 9..35 map 1:1; the swap button is the hotbar index.
            mc.gameMode.handleContainerInput(p.containerMenu.containerId, bestSlot, hot, ContainerInput.SWAP, p);
            timer = delay.i();
            return;
        }
    }
}
