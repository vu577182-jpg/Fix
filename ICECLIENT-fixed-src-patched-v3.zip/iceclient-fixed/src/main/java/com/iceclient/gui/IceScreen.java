package com.iceclient.gui;

import com.iceclient.config.ConfigManager;
import com.iceclient.manager.NotificationManager;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.module.ModuleManager;
import com.iceclient.module.client.ClickGui;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.ModeSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.setting.Setting;
import com.iceclient.setting.StringSetting;
import com.iceclient.util.Animation;
import com.iceclient.util.KeyUtil;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** ICE PRO click GUI: header with logo + search, left sidebar, scrollable module cards, config manager. */
public final class IceScreen extends Screen {
    private static final int MAX_W = 580, MAX_H = 372, HEADER = 46, SIDE = 128, CARD_H = 34, ROW = 22, NUM_ROW = 28;

    // ---- immediate-mode hit regions ----------------------------------------
    private interface Click { void on(int button, int mouseX); }
    private interface Drag { void on(int mouseX); }
    private interface TextTarget { String get(); void set(String s); }

    private record Hit(int x, int y, int w, int h, Click click, Drag drag) {
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private record Tab(String label, Category category) {}

    private final Minecraft game = Minecraft.getInstance();
    private final List<Hit> hits = new ArrayList<>();
    private final List<Tab> tabs = new ArrayList<>();

    // layout
    private int fw, fh, x0, y0;

    // state
    private Category activeTab = Category.COMBAT;
    private float scrollTarget, scrollCurrent;
    private boolean configTab;

    private Module hovered;
    private Hit dragging;
    private TextTarget focus;
    private Module listening;

    private String search = "";
    private String configName = "";

    private final TextTarget searchTarget = new TextTarget() {
        @Override public String get() { return search; }
        @Override public void set(String s) { search = s; scrollTarget = 0; configTab = false; }
    };
    private final TextTarget configNameTarget = new TextTarget() {
        @Override public String get() { return configName; }
        @Override public void set(String s) { configName = s.replaceAll("[^A-Za-z0-9_-]", ""); }
    };

    public IceScreen() {
        super(Component.literal("ICE"));
        for (Category c : Category.values()) {
            if (c == Category.CLIENT || c == Category.HUD) continue;
            tabs.add(new Tab(c.name(), c));
        }
    }

    @Override public boolean isPauseScreen() { return false; }

    // MC 1.21+ Screen API - renderBackground
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        ClickGui cg = ModuleManager.get(ClickGui.class);
        int sw = Render2D.screenW(g), sh = Render2D.screenH(g);
        if (cg == null || cg.dim.on()) g.fill(0, 0, sw, sh, 0x99020509);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        renderBackground(g, mx, my, partialTick);
        hits.clear();
        int sw = Render2D.screenW(g), sh = Render2D.screenH(g);
        fw = Math.min(MAX_W, sw - 16);
        fh = Math.min(MAX_H, sh - 16);
        x0 = (sw - fw) / 2;
        y0 = (sh - fh) / 2;
        drawFrame(g, mx, my);
        super.render(g, mx, my, partialTick);
    }

    // ======================================================================
    // frame
    // ======================================================================
    private void drawFrame(GuiGraphics g, int mx, int my) {
        // main background
        g.fillGradient(x0, y0, x0 + fw, y0 + fh, 0xFF0A1424, 0xFF050910);
        Render2D.border(g, x0, y0, fw, fh, Theme.BORDER);

        // header gradient
        g.fillGradient(x0, y0, x0 + fw, y0 + HEADER, 0xFF0E1A30, 0xFF081018);
        Render2D.hline(g, x0, y0 + HEADER, fw, Theme.BORDER);

        // logo
        Render2D.shard(g, x0 + 16, y0 + HEADER / 2, 5, 9, 0xCC);
        Render2D.shadowText(g, "ICE", x0 + 24, y0 + HEADER / 2 - 4, Theme.PRIMARY);

        // version tag
        Render2D.text(g, "1.2.0", x0 + 24 + Render2D.width("ICE") + 4, y0 + HEADER / 2 - 3, Theme.MUTED);

        // search box
        int sx = x0 + fw - 130, sy = y0 + 10, sw2 = 120, sh2 = 16;
        Render2D.panel(g, sx, sy, sw2, sh2, Theme.alpha(Theme.CARD, 0xC0), Theme.BORDER);
        String sDisplay = search.isEmpty() ? (focus == searchTarget ? "" : "search...") : search;
        Render2D.text(g, (focus == searchTarget ? "|" : "") + sDisplay, sx + 5, sy + 4,
                search.isEmpty() ? Theme.MUTED : Theme.TEXT);
        addHit(sx, sy, sw2, sh2, (btn, px) -> { focus = searchTarget; }, null);

        // sidebar
        int sideX = x0, sideY = y0 + HEADER;
        Render2D.rect(g, sideX, sideY, SIDE, fh - HEADER, Theme.alpha(Theme.BG2, 0xA0));
        Render2D.vline(g, sideX + SIDE, sideY, fh - HEADER, Theme.BORDER);

        int ty = sideY + 8;
        for (Tab t : tabs) {
            boolean active = !configTab && t.category == activeTab && search.isEmpty();
            int tc = active ? Theme.PRIMARY : (isInBounds(mx, my, sideX + 4, ty, SIDE - 8, 18) ? Theme.TEXT : Theme.MUTED);
            if (active) {
                Render2D.rect(g, sideX + 1, ty, 2, 18, Theme.PRIMARY);
                Render2D.rect(g, sideX + 3, ty, SIDE - 4, 18, Theme.alpha(Theme.PRIMARY, 0x22));
            }
            Render2D.text(g, t.label, sideX + 10, ty + 5, tc);
            final Category cat = t.category;
            addHit(sideX + 4, ty, SIDE - 8, 18, (btn, px) -> {
                activeTab = cat; configTab = false; search = ""; scrollTarget = 0;
            }, null);
            ty += 22;
        }

        // config tab entry
        {
            boolean active = configTab;
            int tc = active ? Theme.SECONDARY : (isInBounds(mx, my, sideX + 4, ty, SIDE - 8, 18) ? Theme.TEXT : Theme.MUTED);
            if (active) {
                Render2D.rect(g, sideX + 1, ty, 2, 18, Theme.SECONDARY);
                Render2D.rect(g, sideX + 3, ty, SIDE - 4, 18, Theme.alpha(Theme.SECONDARY, 0x22));
            }
            Render2D.text(g, "Configs", sideX + 10, ty + 5, tc);
            addHit(sideX + 4, ty, SIDE - 8, 18, (btn, px) -> { configTab = true; search = ""; scrollTarget = 0; }, null);
        }

        // content area
        int cx = x0 + SIDE, cy = y0 + HEADER;
        int cw = fw - SIDE;

        if (!search.isEmpty()) {
            drawSearchResults(g, cx, cy, cw, mx, my);
        } else if (configTab) {
            drawConfigPanel(g, cx, cy, cw, mx, my);
        } else {
            drawModuleList(g, cx, cy, cw, mx, my);
        }
    }

    // ======================================================================
    // module list
    // ======================================================================
    private void drawModuleList(GuiGraphics g, int cx, int cy, int cw, int mx, int my) {
        List<Module> mods = new ArrayList<>();
        for (Module m : ModuleManager.byCategory(activeTab)) {
            if (!m.isHidden()) mods.add(m);
        }
        drawScrollableList(g, cx, cy, cw, mx, my, mods);
    }

    private void drawSearchResults(GuiGraphics g, int cx, int cy, int cw, int mx, int my) {
        String q = search.toLowerCase(Locale.ROOT);
        List<Module> results = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (!m.isHidden() && (m.name.toLowerCase(Locale.ROOT).contains(q) ||
                    m.description.toLowerCase(Locale.ROOT).contains(q))) {
                results.add(m);
            }
        }
        drawScrollableList(g, cx, cy, cw, mx, my, results);
    }

    private void drawScrollableList(GuiGraphics g, int cx, int cy, int cw, int mx, int my, List<Module> mods) {
        // scroll
        scrollCurrent += (scrollTarget - scrollCurrent) * 0.18f;
        int contentH = fh - HEADER - 8;
        int totalH = mods.size() * (CARD_H + 4) + expandExtra(mods);
        int maxScroll = Math.max(0, totalH - contentH);
        scrollCurrent = Math.max(0, Math.min(maxScroll, scrollCurrent));
        scrollTarget  = Math.max(0, Math.min(maxScroll, scrollTarget));

        // scissor
        g.enableScissor(cx, cy, cx + cw, cy + contentH);

        int iy = cy + 6 - (int) scrollCurrent;
        for (Module m : mods) {
            drawModuleCard(g, cx + 4, iy, cw - 8, m, mx, my);
            iy += CARD_H + 4;
            if (m.guiExpanded) {
                for (Setting<?> s : m.settings) {
                    drawSettingRow(g, cx + 12, iy, cw - 20, s, m, mx, my);
                    iy += ROW + 2;
                }
                iy += 4;
            }
        }

        g.disableScissor();

        // scrollbar
        if (maxScroll > 0) {
            int barH = Math.max(20, (int) ((float) contentH / totalH * contentH));
            int barY = cy + (int) ((scrollCurrent / maxScroll) * (contentH - barH));
            Render2D.rect(g, cx + cw - 3, barY, 2, barH, Theme.alpha(Theme.BORDER, 0xAA));
        }
    }

    private int expandExtra(List<Module> mods) {
        int extra = 0;
        for (Module m : mods) if (m.guiExpanded) extra += m.settings.size() * (ROW + 2) + 4;
        return extra;
    }

    private void drawModuleCard(GuiGraphics g, int x, int y, int w, Module m, int mx, int my) {
        boolean hover = isInBounds(mx, my, x, y, w, CARD_H);
        m.guiToggle.set(m.isEnabled() ? 1f : 0f);
        m.guiExpand.set(m.guiExpanded ? 1f : 0f);
        float t = m.guiToggle.get();

        int bg = Theme.alpha(m.isEnabled() ? Theme.CARD_ON : Theme.CARD, hover ? 0xFF : 0xE0);
        Render2D.panel(g, x, y, w, CARD_H, bg, m.isEnabled() ? Theme.alpha(Theme.PRIMARY, 0x80) : Theme.BORDER);

        // accent bar
        if (m.isEnabled()) {
            Render2D.rect(g, x + 1, y + 1, 2, CARD_H - 2, Theme.PRIMARY);
        }

        // name + description
        int textX = x + (m.isEnabled() ? 8 : 5);
        Render2D.shadowText(g, m.name, textX, y + 7, m.isEnabled() ? Theme.TEXT : Theme.MUTED);
        String desc = m.description;
        if (Render2D.width(desc) > w - 60) desc = Render2D.trim(desc, w - 64);
        Render2D.text(g, desc, textX, y + 19, Theme.MUTED);

        // info tag
        String info = m.info();
        if (!info.isEmpty()) {
            int iw = Render2D.width(info) + 6;
            Render2D.rect(g, x + w - iw - 20, y + 10, iw, 12, Theme.alpha(Theme.PRIMARY, 0x44));
            Render2D.text(g, info, x + w - iw - 17, y + 12, Theme.PRIMARY);
        }

        // expand arrow
        String arrow = m.guiExpanded ? "v" : ">";
        Render2D.text(g, arrow, x + w - 14, y + 13, m.settings.isEmpty() ? Theme.alpha(Theme.MUTED, 0x40) : Theme.MUTED);

        // hit
        addHit(x, y, w, CARD_H,
                (btn, px) -> {
                    if (btn == 0) m.toggle();
                    else if (btn == 1 && !m.settings.isEmpty()) {
                        m.guiExpanded = !m.guiExpanded;
                        scrollTarget += m.guiExpanded ? m.settings.size() * (ROW + 2) + 4 : 0;
                    }
                }, null);
    }

    private void drawSettingRow(GuiGraphics g, int x, int y, int w, Setting<?> s, Module m, int mx, int my) {
        Render2D.rect(g, x, y, w, ROW, Theme.alpha(Theme.BG2, 0xC0));
        Render2D.text(g, s.name, x + 5, y + 7, Theme.MUTED);

        if (s instanceof BooleanSetting bs) {
            boolean on = bs.on();
            int bx = x + w - 24, by = y + (ROW - 10) / 2;
            Render2D.rect(g, bx, by, 20, 10, Theme.alpha(on ? Theme.PRIMARY : Theme.BORDER, 0xCC));
            Render2D.rect(g, on ? bx + 11 : bx + 1, by + 1, 8, 8, on ? Theme.TEXT : Theme.MUTED);
            addHit(bx - 2, y, 24, ROW, (btn, px) -> { if (btn == 0) bs.toggle(); }, null);

        } else if (s instanceof NumberSetting ns) {
            String val = ns.display();
            Render2D.text(g, val, x + w - Render2D.width(val) - 5, y + 7, Theme.PRIMARY);
            int barX = x + Render2D.width(s.name) + 10;
            int barW = w - Render2D.width(s.name) - Render2D.width(val) - 22;
            if (barW > 10) {
                Render2D.rect(g, barX, y + ROW / 2, barW, 2, Theme.alpha(Theme.BORDER, 0xFF));
                float pct = (float)((ns.d() - ns.min) / (ns.max - ns.min));
                Render2D.rect(g, barX, y + ROW / 2, (int)(barW * pct), 2, Theme.PRIMARY);
                Render2D.rect(g, barX + (int)(barW * pct) - 2, y + ROW / 2 - 3, 4, 8, Theme.TEXT);
                final int bxF = barX, bwF = barW;
                addHit(bxF, y, bwF, ROW,
                        (btn, px) -> { double pctV = Math.max(0, Math.min(1, (double)(px - bxF) / bwF)); ns.set(ns.min + pctV * (ns.max - ns.min)); },
                        px -> { double pctV = Math.max(0, Math.min(1, (double)(px - bxF) / bwF)); ns.set(ns.min + pctV * (ns.max - ns.min)); });
            }

        } else if (s instanceof ModeSetting ms) {
            String cur = ms.get();
            Render2D.text(g, cur, x + w - Render2D.width(cur) - 5, y + 7, Theme.SECONDARY);
            addHit(x + w - Render2D.width(cur) - 10, y, Render2D.width(cur) + 10, ROW,
                    (btn, px) -> { if (btn == 0) ms.cycle(); else if (btn == 1) ms.cycleBack(); }, null);

        } else if (s instanceof StringSetting ss) {
            String v = Render2D.trim(ss.get(), w / 2);
            boolean editing = focus != null && focus.get().equals(ss.get());
            Render2D.text(g, (editing ? "|" : "") + v, x + w - Render2D.width(v) - 5, y + 7, Theme.TEXT);
            final StringSetting ssF = ss;
            addHit(x + w - Render2D.width(v) - 10, y, Render2D.width(v) + 10, ROW,
                    (btn, px) -> { if (btn == 0) focus = new TextTarget() {
                        @Override public String get() { return ssF.get(); }
                        @Override public void set(String sv) { ssF.set(sv); }
                    }; }, null);
        }

        // keybind display (right-click header area)
        if (s == m.settings.get(0)) {
            int key = m.getKey();
            String kb = listening == m ? "..." : (key >= 0 ? KeyUtil.name(key) : "");
            if (!kb.isEmpty()) {
                Render2D.text(g, kb, x + w - Render2D.width(kb) - 5, y - ROW + 7, Theme.MUTED);
            }
        }
    }

    // ======================================================================
    // config panel
    // ======================================================================
    private void drawConfigPanel(GuiGraphics g, int cx, int cy, int cw, int mx, int my) {
        int iy = cy + 10;

        // save input
        int bx = cx + 10, bw = cw - 20;
        boolean editingName = focus == configNameTarget;
        Render2D.panel(g, bx, iy, bw, 18, Theme.alpha(Theme.CARD, 0xC0), editingName ? Theme.PRIMARY : Theme.BORDER);
        String dispName = configName.isEmpty() ? (editingName ? "" : "config name...") : configName;
        Render2D.text(g, (editingName ? "|" : "") + dispName, bx + 6, iy + 5,
                configName.isEmpty() ? Theme.MUTED : Theme.TEXT);
        addHit(bx, iy, bw, 18, (btn, px) -> { focus = configNameTarget; }, null);
        iy += 24;

        // save button
        int saveW = 60;
        Render2D.panel(g, bx, iy, saveW, 16, Theme.alpha(Theme.PRIMARY, 0x33), Theme.PRIMARY);
        Render2D.text(g, "Save", bx + (saveW - Render2D.width("Save")) / 2, iy + 4, Theme.TEXT);
        addHit(bx, iy, saveW, 16, (btn, px) -> {
            if (!configName.isEmpty()) {
                ConfigManager.save(configName);
                NotificationManager.info("Config", "Saved: " + configName);
            }
        }, null);

        iy += 26;
        Render2D.hline(g, cx + 6, iy, cw - 12, Theme.BORDER);
        iy += 8;

        // list existing
        List<String> names = ConfigManager.list();
        g.enableScissor(cx, cy, cx + cw, cy + fh - HEADER - 4);
        scrollCurrent += (scrollTarget - scrollCurrent) * 0.18f;
        int listY = iy - (int) scrollCurrent;
        for (String n : names) {
            boolean hov = isInBounds(mx, my, bx, listY, bw - 44, 16);
            Render2D.panel(g, bx, listY, bw - 44, 16,
                    Theme.alpha(hov ? Theme.CARD_ON : Theme.CARD, 0xC0), Theme.BORDER);
            Render2D.text(g, n, bx + 6, listY + 4, Theme.TEXT);
            // load
            Render2D.panel(g, bx + bw - 42, listY, 20, 16, Theme.alpha(Theme.PRIMARY, 0x33), Theme.PRIMARY);
            Render2D.text(g, "L", bx + bw - 42 + 6, listY + 4, Theme.TEXT);
            final String nn = n;
            addHit(bx + bw - 42, listY, 20, 16, (btn, px) -> {
                ConfigManager.load(nn);
                NotificationManager.info("Config", "Loaded: " + nn);
            }, null);
            // delete
            Render2D.panel(g, bx + bw - 20, listY, 20, 16, Theme.alpha(Theme.DANGER, 0x33), Theme.DANGER);
            Render2D.text(g, "X", bx + bw - 20 + 6, listY + 4, Theme.DANGER);
            addHit(bx + bw - 20, listY, 20, 16, (btn, px) -> {
                ConfigManager.delete(nn);
                NotificationManager.info("Config", "Deleted: " + nn);
            }, null);
            listY += 20;
        }
        g.disableScissor();
    }

    // ======================================================================
    // helpers
    // ======================================================================
    private void addHit(int x, int y, int w, int h, Click click, Drag drag) {
        hits.add(new Hit(x, y, w, h, click, drag));
    }

    private boolean isInBounds(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ======================================================================
    // MC Screen input API (1.21.x standard signatures)
    // ======================================================================
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        focus = null;
        listening = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mouseX, mouseY)) continue;
            if (h.drag() != null) dragging = h;
            h.click().on(button, (int) mouseX);
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null && dragging.drag() != null) {
            dragging.drag().on((int) mouseX);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget -= (float) (scrollY * 34);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            listening.setKey(keyCode == 256 || keyCode == 259 || keyCode == 261 ? -1 : keyCode);
            listening = null;
            return true;
        }
        if (focus != null) {
            if (keyCode == 256 || keyCode == 257 || keyCode == 335) focus = null;
            else if (keyCode == 259) {
                String s = focus.get();
                if (!s.isEmpty()) focus.set(s.substring(0, s.length() - 1));
            }
            return true;
        }
        if (keyCode == 256) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (focus == null) return false;
        int cp = (int) codePoint;
        if (cp < 32 || cp == 127) return false;
        String s = focus.get();
        if (s.length() < 48) focus.set(s + codePoint);
        return true;
    }

    public void close() { onClose(); }
}
