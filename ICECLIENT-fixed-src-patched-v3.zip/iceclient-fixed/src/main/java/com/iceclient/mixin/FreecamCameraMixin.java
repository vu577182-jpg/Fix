package com.iceclient.mixin;

import com.iceclient.module.combat.Freecam;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class FreecamCameraMixin {

    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPosition(double x, double y, double z);

    /**
     * Inject at TAIL of Camera.setup() — MC 1.21.x mojmap method name.
     * If build fails try renaming "setup" to "update".
     */
    @Inject(
        method = "setup",
        at = @At("TAIL")
    )
    private void freecam$setup(CallbackInfo ci) {
        if (!Freecam.active) return;
        setRotation(Freecam.freeYaw, Freecam.freePitch);
        setPosition(Freecam.freeX, Freecam.freeY, Freecam.freeZ);
    }
}
