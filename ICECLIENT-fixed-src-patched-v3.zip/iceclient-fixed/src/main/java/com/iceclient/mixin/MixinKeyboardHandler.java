package com.iceclient.mixin;

import com.iceclient.module.ModuleManager;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public abstract class MixinKeyboardHandler {
    // MC 1.21.x: keyPress(long window, int key, int scanCode, int action, int modifiers)
    @Inject(method = "keyPress", at = @At("HEAD"))
    private void iceclient$onKeyPress(long window, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        // action 1 == GLFW_PRESS. Module keybinds only fire in-world with no screen open.
        if (action != 1) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        ModuleManager.onKey(key);
    }
}
