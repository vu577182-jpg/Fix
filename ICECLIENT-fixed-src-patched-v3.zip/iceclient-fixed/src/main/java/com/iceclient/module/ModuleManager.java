package com.iceclient.module;

import com.iceclient.client.Ice;
import com.iceclient.manager.NotificationManager;
import com.iceclient.module.client.ClickGui;
import com.iceclient.module.combat.AutoAnchor;
import com.iceclient.module.combat.BotPvp;
import com.iceclient.module.combat.AutoCrystal;
import com.iceclient.module.combat.AutoPush;
import com.iceclient.module.combat.AutoTotem;
import com.iceclient.module.combat.AutoXP;
import com.iceclient.module.combat.Freecam;
import com.iceclient.module.combat.Mainhand;
import com.iceclient.module.combat.Surround;
import com.iceclient.module.combat.Velocity;
import com.iceclient.module.hud.ArrayListHud;
import com.iceclient.module.hud.Coordinates;
import com.iceclient.module.hud.EatTimer;
import com.iceclient.module.hud.NotificationHud;
import com.iceclient.module.hud.Watermark;
import com.iceclient.module.misc.ChatIgnore;
import com.iceclient.module.misc.ChatNotify;
import com.iceclient.module.misc.DiscordNotifier;
import com.iceclient.module.misc.FakePlayer;
import com.iceclient.module.misc.ShulkerViewer;
import com.iceclient.module.movement.AutoSprint;
import com.iceclient.module.movement.AutoWalk;
import com.iceclient.module.player.AutoShop;
import com.iceclient.module.player.NoFall;
import com.iceclient.module.player.Replenish;
import com.iceclient.module.render.FullBright;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.clear();
        // Combat
        register(new AutoCrystal());
        register(new AutoAnchor());
        register(new AutoPush());
        register(new Surround());
        register(new Velocity());
        register(new BotPvp());
        register(new AutoTotem());
        register(new AutoXP());
        register(new Mainhand());
        register(new Freecam());
        // Movement
        register(new AutoSprint());
        register(new AutoWalk());
        // Player
        register(new AutoShop());
        register(new NoFall());
        register(new Replenish());
        // Render
        register(new FullBright());
        // HUD
        register(new ArrayListHud());
        register(new Coordinates());
        register(new Watermark());
        register(new EatTimer());
        register(new NotificationHud());
        // Misc
        register(new FakePlayer());
        register(new ShulkerViewer());
        register(new ChatIgnore());
        register(new ChatNotify());
        register(new DiscordNotifier());
        // Client
        register(new ClickGui());
        Ice.LOGGER.info("Registered {} modules", MODULES.size());
    }

    private static void register(Module m) { MODULES.add(m); }

    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public static Module byName(String name) {
        for (Module m : MODULES) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public static void tick() {
        for (Module m : new ArrayList<>(MODULES)) {
            if (!m.isEnabled()) continue;
            if (!m.isWorldReady() && m.requiresWorld()) continue;
            try {
                m.onTick();
            } catch (Throwable t) {
                m.fail("onTick", t);
            }
        }
    }

    public static void render2D(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        for (Module m : new ArrayList<>(MODULES)) {
            if (!m.isEnabled()) continue;
            try {
                m.onRender2D(g);
            } catch (Throwable t) {
                m.fail("onRender2D", t);
            }
        }
        try {
            NotificationManager.render(g);
        } catch (Throwable t) {
            Ice.LOGGER.error("Notification render failed", t);
        }
    }

    /** Called from the keyboard mixin on key press while no screen is open. */
    public static void onKey(int key) {
        for (Module m : new ArrayList<>(MODULES)) {
            if (m.getKey() == key && key >= 0) m.toggle();
        }
    }
}
