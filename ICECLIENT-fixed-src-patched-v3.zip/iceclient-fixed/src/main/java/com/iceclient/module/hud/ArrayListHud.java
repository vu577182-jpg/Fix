package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.module.ModuleManager;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Lists enabled modules on the right edge of the screen with a slide animation. */
public final class ArrayListHud extends Module {
    private final NumberSetting offsetY = add(new NumberSetting("Y", "Offset from the top", 4, 0, 300, 1));
    private final BooleanSetting showInfo = add(new BooleanSetting("ShowInfo", "Append module info (mode, values)", true));

    public ArrayListHud() {
        super("ArrayList", "Danh sach module dang bat.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }

    private String label(Module m) {
        String info = showInfo.on() ? m.info() : "";
        return info.isEmpty() ? m.name : m.name + " " + info;
    }

    @Override
    public void onRender2D(GuiGraphics g) {
        List<Module> all = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (m.isHidden() || m.category == Category.HUD || m.category == Category.CLIENT) continue;
            m.hudSlide.set(m.isEnabled() ? 1f : 0f);
            if (m.isEnabled() || m.hudSlide.get() > 0.01f) all.add(m);
        }
        all.sort(Comparator.comparingInt((Module m) -> Render2D.width(label(m))).reversed());

        int sw = Render2D.screenW(g);
        int y = offsetY.i();
        for (Module m : all) {
            float s = m.hudSlide.get();
            String text = label(m);
            int w = Render2D.width(text) + 10;
            int x = sw - (int) (w * s) - 2;
            Render2D.rect(g, x - 1, y, w + 1, 12, Theme.alpha(Theme.BG, 0xB8));
            Render2D.rect(g, sw - 3 + (int) ((1 - s) * w), y, 2, 12, Theme.PRIMARY);
            Render2D.shadowText(g, m.name, x + 3, y + 2, Theme.PRIMARY);
            String info = showInfo.on() ? m.info() : "";
            if (!info.isEmpty()) Render2D.shadowText(g, info, x + 3 + Render2D.width(m.name) + 4, y + 2, Theme.MUTED);
            y += (int) (12 * Math.min(1f, s * 1.5f));
        }
    }
}
