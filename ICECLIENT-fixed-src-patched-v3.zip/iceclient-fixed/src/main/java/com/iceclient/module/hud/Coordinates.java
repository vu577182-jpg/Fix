package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;

public final class Coordinates extends Module {
    private final NumberSetting x = add(new NumberSetting("X", "Horizontal offset from the left", 6, 0, 600, 1));
    private final NumberSetting yBottom = add(new NumberSetting("Y", "Offset from the bottom", 6, 0, 400, 1));
    private final BooleanSetting other = add(new BooleanSetting("OtherDimension", "Show Overworld/Nether converted coordinates", true));

    public Coordinates() {
        super("Coordinates", "Hien thi toa do cua ban.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }

    @Override
    public void onRender2D(GuiGraphics g) {
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        String main = String.format("XYZ %.1f %.1f %.1f", px, py, pz);
        String second = null;
        if (other.on()) {
            if (mc.level.dimension() == Level.OVERWORLD) second = String.format("Nether %.1f %.1f", px / 8.0, pz / 8.0);
            else if (mc.level.dimension() == Level.NETHER) second = String.format("Overworld %.1f %.1f", px * 8.0, pz * 8.0);
        }
        int w = Math.max(Render2D.width(main), second == null ? 0 : Render2D.width(second)) + 14;
        int h = second == null ? 16 : 27;
        int left = x.i();
        int top = Render2D.screenH(g) - yBottom.i() - h;
        Render2D.panel(g, left, top, w, h, Theme.alpha(Theme.BG, 0xD0), Theme.BORDER);
        Render2D.rect(g, left + 1, top + 1, 2, h - 2, Theme.PRIMARY);
        Render2D.text(g, main, left + 8, top + 4, Theme.TEXT);
        if (second != null) Render2D.text(g, second, left + 8, top + 15, Theme.SECONDARY);
    }
}
