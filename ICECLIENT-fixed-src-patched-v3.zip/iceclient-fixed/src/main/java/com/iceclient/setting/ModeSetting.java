package com.iceclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class ModeSetting extends Setting<String> {
    public final String[] modes;

    public ModeSetting(String name, String description, String value, String... modes) {
        super(name, description, value);
        this.modes = modes;
    }

    public boolean is(String mode) { return value.equalsIgnoreCase(mode); }

    public void cycle()     { cycle(+1); }
    public void cycleBack() { cycle(-1); }

    public void cycle(int dir) {
        int idx = 0;
        for (int i = 0; i < modes.length; i++) if (modes[i].equalsIgnoreCase(value)) idx = i;
        idx = Math.floorMod(idx + dir, modes.length);
        value = modes[idx];
    }

    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) {
        if (e == null || !e.isJsonPrimitive()) return;
        String s = e.getAsString();
        for (String m : modes) if (m.equalsIgnoreCase(s)) { value = m; return; }
    }
}
